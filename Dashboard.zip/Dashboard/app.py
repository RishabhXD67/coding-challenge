from flask import Flask, render_template, redirect, url_for, request, flash
from config import Config
from models import db, User, SolvedProblem
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import date
import requests

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)

login_manager = LoginManager()
login_manager.login_view = "login"
login_manager.init_app(app)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

with app.app_context():
    db.create_all()

# Dummy coding problems (simulating API)
PROBLEMS = [
    {
        "title": "Two Sum",
        "difficulty": "Easy",
        "description": "Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.",
        "example": "Input: nums = [2,7,11,15], target = 9\nOutput: [0,1]"
    },
    {
        "title": "Merge Intervals",
        "difficulty": "Medium",
        "description": "Given an array of intervals where intervals[i] = [start, end], merge all overlapping intervals.",
        "example": "Input: [[1,3],[2,6],[8,10]]\nOutput: [[1,6],[8,10]]"
    },
    {
        "title": "LRU Cache",
        "difficulty": "Hard",
        "description": "Design a data structure that follows the constraints of a Least Recently Used cache.",
        "example": "Operations: put(1,1), put(2,2), get(1)"
    }
]

def get_daily_problem():
    today = date.today().day
    return PROBLEMS[today % len(PROBLEMS)]

@app.route("/")
@login_required
def dashboard():
    solved_problems = SolvedProblem.query.filter_by(
        user_id=current_user.id
    ).order_by(SolvedProblem.date_solved.desc()).all()

    return render_template(
        "dashboard.html",
        solved_count=len(solved_problems),
        solved_problems=solved_problems
    )

@app.route("/problem")
@login_required
def problem():
    problem = get_daily_problem()
    return render_template("problem.html", problem=problem)

@app.route("/solve")
@login_required
def solve():
    problem = get_daily_problem()

    existing = SolvedProblem.query.filter_by(
        user_id=current_user.id,
        problem_title=problem["title"]
    ).first()

    if not existing:
        new_solve = SolvedProblem(
            user_id=current_user.id,
            problem_title=problem["title"]
        )
        db.session.add(new_solve)
        db.session.commit()
        flash("Marked as solved!")

    return redirect(url_for("dashboard"))

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username")
        password = generate_password_hash(request.form.get("password"))

        if User.query.filter_by(username=username).first():
            flash("Username already exists")
            return redirect(url_for("register"))

        user = User(username=username, password=password)
        db.session.add(user)
        db.session.commit()
        return redirect(url_for("login"))

    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user = User.query.filter_by(username=request.form.get("username")).first()

        if user and check_password_hash(user.password, request.form.get("password")):
            login_user(user)
            return redirect(url_for("dashboard"))

        flash("Invalid credentials")

    return render_template("login.html")

@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("login"))

if __name__ == "__main__":
    app.run(debug=True)